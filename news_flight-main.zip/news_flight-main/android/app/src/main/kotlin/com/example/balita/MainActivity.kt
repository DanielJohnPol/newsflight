package com.example.news_flight

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
